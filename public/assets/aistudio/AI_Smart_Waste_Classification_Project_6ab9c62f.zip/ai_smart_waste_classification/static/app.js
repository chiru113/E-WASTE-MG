// Place your exported Teachable Machine files in static/model/.
// The folder must contain model.json, metadata.json and the weights file(s).
const MODEL_URL = "/static/model/";
const recommendations = {
  plastic: "Place clean plastic in the locally designated dry-recycling bin. Check the recycling symbol and local rules.",
  paper: "Keep paper dry and clean, then place it in the paper-recycling stream where accepted.",
  metal: "Empty and rinse metal cans where appropriate, then use the local metal-recycling stream.",
  glass: "Handle glass carefully. Separate it according to local glass collection rules.",
  organic: "Put suitable food and garden scraps in a compost or wet-waste collection stream.",
  other: "The item was not confidently matched to a supported category. Check local disposal guidance."
};
let model = null, webcam = null, cameraLoop = false, lastCameraSaveAt = 0, lastCameraSavedCategory = '';
const $ = id => document.getElementById(id);
const statusEl = $("modelStatus");

async function loadModel() {
  try {
    model = await tmImage.load(MODEL_URL + "model.json", MODEL_URL + "metadata.json");
    statusEl.textContent = "Model loaded";
    statusEl.style.background = "#e5f5eb";
  } catch (error) {
    statusEl.textContent = "Add trained model files";
    $("message").textContent = "Train and export an Image model from Teachable Machine, then copy its files into static/model/.";
    console.warn("Model loading failed:", error);
  }
}
function recommendationFor(label) {
  const key = label.toLowerCase();
  for (const [category, text] of Object.entries(recommendations)) {
    if (key.includes(category)) return text;
  }
  return recommendations.other;
}
async function classify(source, fromCamera = false) {
  if (!model) { $("message").textContent = "AI model is not loaded yet. Add your exported model files."; return; }
  try {
    const predictions = await model.predict(source);
    predictions.sort((a,b) => b.probability - a.probability);
    const best = predictions[0];
    const confidence = best.probability;
    $("prediction").textContent = confidence >= 0.60 ? best.className : "Uncertain result";
    $("confidence").textContent = `Confidence: ${(confidence*100).toFixed(1)}%`;
    $("confidenceBar").style.width = `${confidence*100}%`;
    $("recommendation").textContent = confidence >= 0.60 ? recommendationFor(best.className) : "Try a clearer image with one waste item, good lighting and a plain background.";
    if (confidence >= 0.60) await savePrediction(best.className, confidence);
    $("message").textContent = confidence >= 0.60 ? "Prediction completed and saved." : "Prediction not saved because confidence is below 60%.";
  } catch (error) {
    console.error(error); $("message").textContent = "Could not classify this image. Please try another image.";
  }
}
async function savePrediction(category, confidence) {
  const response = await fetch("/api/predictions", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({category, confidence})
  });
  if (!response.ok) throw new Error("Could not save prediction");
}
$("imageInput").addEventListener("change", event => {
  const file = event.target.files[0]; if (!file) return;
  if (!file.type.startsWith("image/")) { $("message").textContent = "Please select an image file."; return; }
  const url = URL.createObjectURL(file);
  $("preview").src = url; $("preview").hidden = false;
  $("emptyState").hidden = true; $("cameraContainer").innerHTML = "";
  $("message").textContent = "Analyzing image…";
  $("preview").onload = () => classify($("preview"));
});
$("startCamera").addEventListener("click", async () => {
  if (!model) { $("message").textContent = "Load your Teachable Machine model first."; return; }
  try {
    webcam = new tmImage.Webcam(320, 240, true);
    await webcam.setup(); await webcam.play();
    $("preview").hidden = true; $("emptyState").hidden = true;
    $("cameraContainer").innerHTML = ""; $("cameraContainer").appendChild(webcam.canvas);
    $("startCamera").disabled = true; $("stopCamera").disabled = false;
    cameraLoop = true; cameraTick();
  } catch (error) { $("message").textContent = "Camera access failed. Allow camera permission or use image upload."; }
});
async function cameraTick() {
  if (!cameraLoop || !webcam) return;
  webcam.update(); await classify(webcam.canvas);
  if (cameraLoop) requestAnimationFrame(cameraTick);
}
$("stopCamera").addEventListener("click", () => {
  cameraLoop = false;
  if (webcam) webcam.stop();
  webcam = null; $("cameraContainer").innerHTML = "";
  $("emptyState").hidden = false; $("startCamera").disabled = false; $("stopCamera").disabled = true;
});
loadModel();
