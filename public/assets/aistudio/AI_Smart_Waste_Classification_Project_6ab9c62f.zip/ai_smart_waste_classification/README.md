# EcoSort AI — Smart Waste Classification

A student major-project starter using Google Teachable Machine, TensorFlow.js, Flask and SQLite.

## Features
- Image upload classification
- Webcam classification
- Confidence display and disposal guidance
- Flask API to save prediction history
- SQLite database and dashboard statistics

## 1. Requirements
- Python 3.10 or newer
- VS Code
- Chrome or Edge
- Internet connection for the TensorFlow.js / Teachable Machine CDN scripts

## 2. Create and train your model
1. Open https://teachablemachine.withgoogle.com/
2. Select **Get Started → Image Project → Standard Image Model**.
3. Create classes with these exact names: `Plastic`, `Paper`, `Metal`, `Glass`, `Organic`, `Other`.
4. Add varied images for each class. Include different backgrounds, lighting, angles and examples.
5. Keep some images aside for testing; do not use the same images for training and testing.
6. Train the model and evaluate it on images it has not seen.
7. Select **Export Model → Tensorflow.js → Download my model**.
8. Extract the download. Copy `model.json`, `metadata.json` and all weight files into this project's `static/model/` folder. Create that folder if needed.
9. Confirm that `static/model/model.json` and `static/model/metadata.json` exist.

The `Other` class should contain ordinary items outside the target classes. It is not a reliable hazardous-waste detector. Do not use the prototype for hazardous waste decisions.

## 3. VS Code setup

Open the project folder in VS Code. In the terminal:

### Windows PowerShell
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

If PowerShell blocks activation, use Command Prompt:
```bat
.venv\Scripts\activate.bat
pip install -r requirements.txt
python app.py
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 in your browser. Dashboard: http://127.0.0.1:5000/dashboard

Camera access generally works on localhost. Allow camera permission in your browser.

## 4. Project structure
```text
ai_smart_waste_classification/
├── app.py
├── requirements.txt
├── README.md
├── waste_history.db        # created automatically
├── templates/
│   ├── index.html
│   └── dashboard.html
└── static/
    ├── style.css
    ├── app.js
    └── model/              # add exported model files here
        ├── model.json
        ├── metadata.json
        └── *.bin
```

## 5. API endpoints
- `GET /api/health` — server status
- `POST /api/predictions` — save `{ "category": "Plastic", "confidence": 0.93 }`
- `GET /api/predictions` — latest 100 records
- `GET /api/stats` — totals by category

## 6. Testing checklist
- [ ] Flask server starts without errors.
- [ ] Home page loads.
- [ ] Exported model loads and status changes to “Model loaded”.
- [ ] Upload a clear test image for each class.
- [ ] Webcam starts after permission is granted.
- [ ] Low-confidence result asks for a clearer image.
- [ ] Successful prediction appears on the dashboard.
- [ ] Refreshing the dashboard retains history in SQLite.
- [ ] Test unfamiliar items and record false predictions.

## 7. Evaluation for your report
Use a separate test set. For each class, record:
- True positives, false positives, true negatives and false negatives
- Precision = TP / (TP + FP)
- Recall = TP / (TP + FN)
- F1 score = 2 × Precision × Recall / (Precision + Recall)
- Overall accuracy = correct predictions / total test predictions

Create a confusion matrix and report per-class results. Do not claim an accuracy percentage until you have measured it.

## 8. Limitations and future enhancements
- Predictions depend on the quality and variety of training images.
- A single photo may contain several waste materials; this classifier predicts one class for the whole image.
- Confidence is not a guarantee that a prediction is correct.
- Disposal rules vary by location.
- Future work: multi-object detection, multilingual UI, QR-coded collection bins, collection-centre map, and IoT-enabled smart bins.

## Academic note
This is a working project scaffold. The trained Teachable Machine model is not included; you must train and export your own model and add its files under `static/model/` before classification works.
