from flask import Flask, render_template, request, jsonify
import sqlite3
from pathlib import Path
from datetime import datetime

app = Flask(__name__)
DB_PATH = Path(__file__).parent / "waste_history.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                confidence REAL NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "message": "Waste classification API is running"})

@app.post("/api/predictions")
def save_prediction():
    data = request.get_json(silent=True) or {}
    category = str(data.get("category", "")).strip()
    confidence = data.get("confidence")

    if not category or len(category) > 60:
        return jsonify({"error": "A valid category is required."}), 400
    try:
        confidence = float(confidence)
    except (TypeError, ValueError):
        return jsonify({"error": "A valid confidence score is required."}), 400
    if not 0 <= confidence <= 1:
        return jsonify({"error": "Confidence must be between 0 and 1."}), 400

    created_at = datetime.now().astimezone().isoformat(timespec="seconds")
    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO predictions(category, confidence, created_at) VALUES (?, ?, ?)",
            (category, confidence, created_at)
        )
        record_id = cur.lastrowid
    return jsonify({"message": "Prediction saved", "id": record_id}), 201

@app.get("/api/predictions")
def get_predictions():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT id, category, confidence, created_at FROM predictions ORDER BY id DESC LIMIT 100"
        ).fetchall()
    return jsonify([dict(row) for row in rows])

@app.get("/api/stats")
def get_stats():
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) AS n FROM predictions").fetchone()["n"]
        rows = conn.execute(
            "SELECT category, COUNT(*) AS count FROM predictions GROUP BY category ORDER BY count DESC"
        ).fetchall()
    return jsonify({"total": total, "categories": [dict(row) for row in rows]})

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
